package com.example.newsapp.Model

data class Category(
    var id:Int,
    var category:String
)
