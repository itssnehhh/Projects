package com.example.newsapp.Model

data class DataNews(
    var status: String,
    var totalResults: Int,
    var articles:MutableList<Article>
)
