package com.example.newsapp.Model

data class Source(
    var id: String? = null,
    var name: String
)
